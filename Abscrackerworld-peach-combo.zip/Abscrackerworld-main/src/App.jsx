import { useEffect, useState } from "react";
import { Routes, Route } from "react-router-dom";
import { Toaster } from "sonner";
import SplashScreen from "./components/splash/SplashScreen";
import Home from "./pages/Home";
import CategoryListing from "./pages/CategoryListing";
import Cart from "./pages/Cart";
import Checkout from "./pages/Checkout";
import OrderHistory from "./pages/OrderHistory";
import TrackOrder from "./pages/TrackOrder";
import Profile from "./pages/Profile";
import AmbientBackground from "./components/ui/AmbientBackground";
import GlobalFestiveFX from "./components/ui/GlobalFestiveFX";
import CustomerDetailsSheet from "./components/customer/CustomerDetailsSheet";
import EditOrderBar from "./components/orders/EditOrderBar";
import { useCartFirestoreSync } from "./hooks/useCartFirestoreSync";
import { ProductsProvider } from "./contexts/ProductsContext";
import { AdminAuthProvider } from "./contexts/AdminAuthContext";
import { AdminDataProvider } from "./contexts/AdminDataContext";
import AdminRoute from "./components/admin/AdminRoute";
import AdminLogin from "./pages/admin/AdminLogin";
import AdminOverview from "./pages/admin/AdminOverview";
import AdminDashboard from "./pages/admin/AdminDashboard";
import AdminPaymentConfirmation from "./pages/admin/AdminPaymentConfirmation";
import AdminPacking from "./pages/admin/AdminPacking";
import AdminDelivery from "./pages/admin/AdminDelivery";
import AdminProductInsights from "./pages/admin/AdminProductInsights";
import AdminProducts from "./pages/admin/AdminProducts";
import AdminPriceUpdate from "./pages/admin/AdminPriceUpdate";
import AdminOrderLimits from "./pages/admin/AdminOrderLimits";
import AdminInventory from "./pages/admin/AdminInventory";
import AdminCategories from "./pages/admin/AdminCategories";
import AdminCombos from "./pages/admin/AdminCombos";
import AdminInvoices from "./pages/admin/AdminInvoices";
import AdminEstimates from "./pages/admin/AdminEstimates";
import AdminUsers from "./pages/admin/AdminUsers";

const SPLASH_DURATION_MS = 4200;

// The customer-facing storefront — kept inside the fixed-width "phone
// screen" shell exactly as before.
function CustomerApp() {
  const [showSplash, setShowSplash] = useState(true);
  useCartFirestoreSync();

  useEffect(() => {
    const timer = setTimeout(() => setShowSplash(false), SPLASH_DURATION_MS);
    return () => clearTimeout(timer);
  }, []);

  return (
    <ProductsProvider>
      <div
        id="app-shell"
        className="relative w-full max-w-[430px] overflow-hidden bg-bg text-brown"
        style={{ transform: 'translateZ(0)', height: '100dvh' }}
      >
        <AmbientBackground />
        {/* Site-wide scroll-triggered firework/fountain flourish — lives
            here (not inside Home) so it plays on every customer screen
            that shares this #app-scroll container. */}
        <GlobalFestiveFX />
        <SplashScreen visible={showSplash} onSkip={() => setShowSplash(false)} />
        <div
          id="app-scroll"
          className="relative h-full w-full overflow-y-auto overflow-x-hidden"
          style={{ WebkitOverflowScrolling: 'touch' }}
        >
          {!showSplash && (
            <div className="relative z-10">
              <Routes>
                <Route path="/" element={<Home />} />
                <Route path="/category/:slug" element={<CategoryListing />} />
                <Route path="/cart" element={<Cart />} />
                <Route path="/checkout" element={<Checkout />} />
                <Route path="/orders" element={<OrderHistory />} />
                <Route path="/track-order" element={<TrackOrder />} />
                <Route path="/profile" element={<Profile />} />
              </Routes>
            </div>
          )}
        </div>
        <CustomerDetailsSheet />
        <EditOrderBar />
      </div>
    </ProductsProvider>
  );
}

// The admin panel — deliberately rendered OUTSIDE the 430px mobile shell
// (full width) since staff will mostly manage orders from a desktop/laptop.
// Has its own auth provider so the customer flow never touches Firebase Auth.
function AdminApp() {
  return (
    <AdminAuthProvider>
      {/* Products/Categories management screens read the live catalog via
          useProducts(), so the admin panel needs its own ProductsProvider —
          separate from CustomerApp's, since the two shells never mount together.
          includeHidden=true so admins can still see/edit/re-show products
          that are hidden from the customer-facing storefront. */}
      <ProductsProvider includeHidden>
       <AdminDataProvider>
        <div
          className="relative w-full overflow-y-auto overflow-x-hidden"
          style={{ height: '100dvh', WebkitOverflowScrolling: 'touch' }}
        >
          <Routes>
            <Route path="login" element={<AdminLogin />} />
            <Route
              path="orders"
              element={
                <AdminRoute>
                  <AdminDashboard />
                </AdminRoute>
              }
            />
            <Route
              path="payment-confirmation"
              element={
                <AdminRoute>
                  <AdminPaymentConfirmation />
                </AdminRoute>
              }
            />
            <Route
              path="packing"
              element={
                <AdminRoute>
                  <AdminPacking />
                </AdminRoute>
              }
            />
            <Route
              path="delivery"
              element={
                <AdminRoute>
                  <AdminDelivery />
                </AdminRoute>
              }
            />
            <Route
              path="product-insights"
              element={
                <AdminRoute>
                  <AdminProductInsights />
                </AdminRoute>
              }
            />
            <Route
              path="products"
              element={
                <AdminRoute>
                  <AdminProducts />
                </AdminRoute>
              }
            />
            <Route
              path="price-update"
              element={
                <AdminRoute>
                  <AdminPriceUpdate />
                </AdminRoute>
              }
            />
            <Route
              path="order-limits"
              element={
                <AdminRoute>
                  <AdminOrderLimits />
                </AdminRoute>
              }
            />
            <Route
              path="inventory"
              element={
                <AdminRoute>
                  <AdminInventory />
                </AdminRoute>
              }
            />
            <Route
              path="categories"
              element={
                <AdminRoute>
                  <AdminCategories />
                </AdminRoute>
              }
            />
            <Route
              path="combos"
              element={
                <AdminRoute>
                  <AdminCombos />
                </AdminRoute>
              }
            />
            <Route
              path="invoices"
              element={
                <AdminRoute>
                  <AdminInvoices />
                </AdminRoute>
              }
            />
            <Route
              path="estimates"
              element={
                <AdminRoute>
                  <AdminEstimates />
                </AdminRoute>
              }
            />
            <Route
              path="users"
              element={
                <AdminRoute>
                  <AdminUsers />
                </AdminRoute>
              }
            />
            <Route
              path="*"
              element={
                <AdminRoute>
                  <AdminOverview />
                </AdminRoute>
              }
            />
          </Routes>
        </div>
       </AdminDataProvider>
      </ProductsProvider>
    </AdminAuthProvider>
  );
}

export default function App() {
  return (
    <>
      <Routes>
        <Route path="/admin/*" element={<AdminApp />} />
        <Route path="/*" element={<CustomerApp />} />
      </Routes>

      <Toaster
        theme="light"
        position="bottom-center"
        toastOptions={{
          style: {
            background: "#ffffff",
            border: "1px solid rgba(255,138,101,.5)",
            color: "#71321F",
            fontSize: "12.5px",
          },
        }}
      />
    </>
  );
}
