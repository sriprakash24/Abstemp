// Firestore order submission — orders/{orderId}
//
// Manual payment workflow: the customer never pays inside the app. An order
// is written with status AWAITING_ADMIN_CONFIRMATION / paymentStatus PENDING,
// and the ABS Crackers World team follows up over WhatsApp or phone.

import {
  doc,
  setDoc,
  deleteDoc,
  updateDoc,
  serverTimestamp,
  increment,
  collection,
  query,
  where,
  orderBy,
  limit,
  getDoc,
  getDocs,
  onSnapshot,
  writeBatch,
} from "firebase/firestore";
import { reserveSequentialId } from "../utils/sequentialId";
import { formatFullAddress } from "../utils/formatAddress";
import { computeCartDiff } from "../utils/orderEditDiff";

/**
 * Generates the order id, e.g. "ABSO20260801108" — ABSO + today's date +
 * a 3-digit counter that resets daily. See src/utils/sequentialId.js for
 * the shared format (invoices use the same helper with the ABSI prefix).
 */
export function generateOrderId(db) {
  return reserveSequentialId(db, { prefix: "ABSO", counterKey: "orders" });
}

/**
 * Shapes the Firestore payload for a new order from the checkout form values,
 * the derived cart pricing, and the cart line items.
 */
export function buildOrderPayload({ orderId, formValues, pricing }) {
  const {
    fullName,
    mobile,
    alternateMobile,
    email,
    houseNumber,
    street,
    area,
    city,
    district,
    state,
    pincode,
    landmark,
    deliveryNotes,
    orderNotes,
  } = formValues;

  return {
    orderId,
    customer: {
      name: fullName.trim(),
      mobile: mobile.trim(),
      alternateMobile: alternateMobile?.trim() || "",
      email: email?.trim() || "",
    },
    address: {
      houseNumber: houseNumber.trim(),
      street: street.trim(),
      area: area.trim(),
      city: city.trim(),
      district: district.trim(),
      state: state.trim(),
      pincode: pincode.trim(),
      landmark: landmark?.trim() || "",
      deliveryNotes: deliveryNotes?.trim() || "",
    },
    orderNotes: orderNotes?.trim() || "",
    cartItems: pricing.items.map(({ product, qty }) => ({
      productId: product.id,
      name: product.name,
      nameTa: product.nameTa || "",
      image: product.img || "",
      category: product.category,
      unitPrice: product.sale,
      mrp: product.mrp,
      quantity: qty,
      lineTotal: product.sale * qty,
    })),
    subtotal: pricing.subtotalMrp,
    discount: pricing.discount + pricing.couponDiscount,
    packingCharges: pricing.packingCharges,
    deliveryCharges: pricing.deliveryCharges,
    grandTotal: pricing.grandTotal,
    totalSavings: pricing.totalSavings,
    orderStage: "ORDER_SUBMITTED",
    status: "AWAITING_ADMIN_CONFIRMATION",
    paymentStatus: "PENDING",
    createdAt: serverTimestamp(),
    updatedAt: serverTimestamp(),
  };
}

/** Writes a new order document to orders/{orderId}. */
export async function submitOrder(db, { formValues, pricing }) {
  const orderId = await generateOrderId(db);
  const payload = buildOrderPayload({ orderId, formValues, pricing });
  const ref = doc(db, "orders", orderId);
  await setDoc(ref, payload);
  return { orderId };
}

/**
 * Live-subscribes to every order placed by this mobile number, newest first
 * — powers the Order History screen so admin status updates (confirmed,
 * packed, delivered...) reflect instantly without a manual refresh.
 *
 * Usage: `const unsub = subscribeOrdersByMobile(db, mobile, setOrders, onError);`
 * — call the returned function on unmount to detach the listener.
 */
export function subscribeOrdersByMobile(db, mobile, onChange, onError) {
  if (!db || !mobile) {
    onChange([]);
    return () => {};
  }

  const q = query(
    collection(db, "orders"),
    where("customer.mobile", "==", mobile.trim()),
    orderBy("createdAt", "desc"),
  );

  return onSnapshot(
    q,
    (snapshot) => {
      const orders = snapshot.docs.map((d) => ({ id: d.id, ...d.data() }));
      onChange(orders);
    },
    (err) => {
      console.error("Failed to load order history", err);
      onError?.(err);
    },
  );
}

/**
 * One-time fetch of the delivery address from this mobile's most recent
 * order — used to prefill the "My Profile" edit page the first time a
 * customer opens it (before they've ever saved a standalone profile
 * address), since their most reliable existing address is whatever they
 * last typed in at checkout. Returns null if they have no orders yet.
 */
export async function getLatestOrderAddress(db, mobile) {
  if (!db || !mobile) return null;
  const q = query(
    collection(db, "orders"),
    where("customer.mobile", "==", mobile.trim()),
    orderBy("createdAt", "desc"),
    limit(1),
  );
  const snapshot = await getDocs(q);
  if (snapshot.empty) return null;
  return snapshot.docs[0].data().address ?? null;
}

/**
 * Pushes a corrected address onto every one of this customer's orders —
 * and onto the `customer.address` of any invoice already generated from
 * them (see createInvoiceForOrder / createInvoiceForMergedOrders in
 * invoicesFirestore.js) — called right after the address is edited on
 * either "My Profile" (customer) or the admin Users page (see
 * usersFirestore.js's saveUserAddress / updateUserProfile).
 *
 * There's no GST/accounting requirement here to keep an already-issued
 * invoice's address as a locked historical record, so this deliberately
 * covers every order for this mobile regardless of status, not just
 * still-pending ones — an address fix should show up everywhere,
 * including on invoices already printed/downloaded before the correction.
 * A merged invoice (one invoice shared by several child orders) is only
 * patched once even though several of its child orders point at it.
 */
export async function syncAddressToOrders(db, mobile, address) {
  if (!db || !mobile || !address) return;
  const q = query(
    collection(db, "orders"),
    where("customer.mobile", "==", mobile.trim()),
  );
  const snapshot = await getDocs(q);
  if (snapshot.empty) return;

  const batch = writeBatch(db);
  const formattedAddress = formatFullAddress(address);
  const syncedInvoiceIds = new Set();

  snapshot.docs.forEach((d) => {
    batch.update(d.ref, { address, updatedAt: serverTimestamp() });

    const invoiceId = d.data().invoiceId;
    if (invoiceId && !syncedInvoiceIds.has(invoiceId)) {
      syncedInvoiceIds.add(invoiceId);
      batch.update(doc(db, "invoices", invoiceId), {
        "customer.address": formattedAddress,
        updatedAt: serverTimestamp(),
      });
    }
  });

  await batch.commit();
}

/**
 * Live-subscribes to every order in the store, newest first — powers the
 * admin Order Management page. Unlike `subscribeOrdersByMobile`, this has
 * no `where` filter, so it relies only on the `createdAt` index Firestore
 * creates automatically for a single-field `orderBy`.
 *
 * Usage: `const unsub = subscribeAllOrders(db, setOrders, onError);`
 * — call the returned function on unmount to detach the listener.
 */
export function subscribeAllOrders(db, onChange, onError) {
  if (!db) {
    onChange([]);
    return () => {};
  }

  const q = query(collection(db, "orders"), orderBy("createdAt", "desc"));

  return onSnapshot(
    q,
    (snapshot) => {
      const orders = snapshot.docs.map((d) => ({ id: d.id, ...d.data() }));
      onChange(orders);
    },
    (err) => {
      console.error("Failed to load orders", err);
      onError?.(err);
    },
  );
}

/**
 * Applies an admin-driven status change to orders/{orderDocId} — e.g.
 * confirming payment, moving to packed/out-for-delivery/delivered, or
 * cancelling. Always stamps `updatedAt` so the customer's live order
 * history reflects the change immediately.
 *
 * `patch` is a partial object, e.g. `{ status: 'PACKED' }` or
 * `{ status: 'CONFIRMED', paymentStatus: 'RECEIVED' }`.
 */
export async function updateOrderStatus(db, orderDocId, patch) {
  const ref = doc(db, "orders", orderDocId);
  await updateDoc(ref, { ...patch, updatedAt: serverTimestamp() });
}

/**
 * Recomputes order pricing from a plain list of { product, qty } — the
 * same formulas useCartStore.getPricing() uses for the live cart, kept as
 * a standalone function here so editing an already-placed order doesn't
 * need to touch (or clobber) whatever's currently in the customer's cart.
 * Note: any coupon originally applied at checkout isn't re-applied here —
 * order docs only store the already-combined discount total, not which
 * coupon code was used, so an edited order is repriced without one.
 */
export function computeOrderPricing(items) {
  const PACKING_CHARGE_RATE = 0.03;
  const subtotalMrp = items.reduce(
    (sum, { product, qty }) => sum + product.mrp * qty,
    0,
  );
  const subtotalSale = items.reduce(
    (sum, { product, qty }) => sum + product.sale * qty,
    0,
  );
  const discount = Math.max(0, subtotalMrp - subtotalSale);
  const packingCharges = Math.round(subtotalSale * PACKING_CHARGE_RATE);
  const grandTotal = Math.max(0, subtotalSale + packingCharges);

  return {
    cartItems: items.map(({ product, qty }) => ({
      productId: product.id,
      name: product.name,
      nameTa: product.nameTa || "",
      image: product.img || "",
      category: product.category,
      unitPrice: product.sale,
      mrp: product.mrp,
      quantity: qty,
      lineTotal: product.sale * qty,
    })),
    subtotal: subtotalMrp,
    discount,
    packingCharges,
    deliveryCharges: 0,
    grandTotal,
    totalSavings: discount,
  };
}

/**
 * Applies a customer-driven item edit to orders/{orderDocId} — only ever
 * called while the order is still AWAITING_ADMIN_CONFIRMATION (see
 * OrderCard's "Edit Order" button and EditOrderReviewModal's "Confirm"),
 * so this never touches `status`. Recomputes every pricing field from the
 * new item list so nothing goes stale.
 *
 * Also records the edit for the admin Order Management page:
 *   - `edited` / `editCount` / `lastEditedAt` on the order doc itself, so
 *     the list can badge + filter "edited" orders with no extra reads.
 *   - `lastEditDiff` (see computeCartDiff) on the order doc, so the card
 *     can highlight exactly which line items changed without fetching
 *     history.
 *   - a full snapshot (before + after) appended to the
 *     orders/{orderDocId}/editHistory subcollection, so every past edit —
 *     not just the latest — stays inspectable (see getOrderEditHistory).
 * Reads the order doc first (inside the same call, not a transaction —
 * two customers editing the same order at once isn't a real scenario here)
 * to capture the "before" snapshot, since it would otherwise be gone the
 * instant this overwrites it.
 */
export async function updateOrderItems(db, orderDocId, items) {
  const pricing = computeOrderPricing(items);
  const ref = doc(db, "orders", orderDocId);

  const snap = await getDoc(ref);
  const previous = snap.exists() ? snap.data() : null;
  const previousItems = previous?.cartItems || [];
  const diff = computeCartDiff(previousItems, pricing.cartItems);

  const batch = writeBatch(db);
  const patch = { ...pricing, updatedAt: serverTimestamp() };

  // Only badge this as an "edit" when the item list actually changed —
  // re-opening Edit Order and confirming with nothing changed shouldn't
  // light up the Edited filter/badge or add a no-op history entry.
  if (diff.hasChanges) {
    patch.edited = true;
    patch.editCount = increment(1);
    patch.lastEditedAt = serverTimestamp();
    patch.lastEditDiff = diff;
  }
  batch.update(ref, patch);

  if (diff.hasChanges && previous) {
    const historyRef = doc(collection(db, "orders", orderDocId, "editHistory"));
    batch.set(historyRef, {
      editedAt: serverTimestamp(),
      previousCartItems: previousItems,
      previousPricing: {
        subtotal: previous.subtotal ?? 0,
        discount: previous.discount ?? 0,
        packingCharges: previous.packingCharges ?? 0,
        deliveryCharges: previous.deliveryCharges ?? 0,
        grandTotal: previous.grandTotal ?? 0,
      },
      newCartItems: pricing.cartItems,
      newPricing: {
        subtotal: pricing.subtotal,
        discount: pricing.discount,
        packingCharges: pricing.packingCharges,
        deliveryCharges: pricing.deliveryCharges,
        grandTotal: pricing.grandTotal,
      },
      diff,
    });
  }

  await batch.commit();
}

/**
 * One-time fetch of every past edit for one order, newest first — powers
 * the "Edit History" view on the admin Order Management card (see
 * AdminOrderCard's EditHistoryModal). Each entry is a full before/after
 * snapshot written by updateOrderItems above.
 */
export async function getOrderEditHistory(db, orderDocId) {
  const q = query(
    collection(db, "orders", orderDocId, "editHistory"),
    orderBy("editedAt", "desc"),
  );
  const snapshot = await getDocs(q);
  return snapshot.docs.map((d) => ({ id: d.id, ...d.data() }));
}

/**
 * Tracks whether the admin has sent the WhatsApp bill message and/or bill
 * file for this order — powers the little checkboxes next to the Message /
 * Bill buttons on the order card so it's obvious at a glance what's still
 * pending, even after a page refresh (the flags live on the order doc, not
 * local state). Pass only the flag(s) that changed, e.g.
 * `markBillWhatsappSent(db, orderDocId, { messageSent: true })`.
 * Setting a flag to `false` clears its timestamp (used when the admin
 * un-ticks a checkbox by mistake).
 */
export async function markBillWhatsappSent(
  db,
  orderDocId,
  { messageSent, fileSent } = {},
) {
  const ref = doc(db, "orders", orderDocId);
  const patch = { updatedAt: serverTimestamp() };
  if (messageSent !== undefined) {
    patch.billMessageSentAt = messageSent ? serverTimestamp() : null;
  }
  if (fileSent !== undefined) {
    patch.billFileSentAt = fileSent ? serverTimestamp() : null;
  }
  await updateDoc(ref, patch);
}

/**
 * Marks every order doc in a merged packing group (same customer mobile,
 * possibly several order docs across different dates — see AdminPacking.jsx)
 * as PACKED in a single atomic batch, so the whole customer's job moves
 * together instead of some orders advancing while a write fails on another.
 */
export async function markOrdersPacked(db, orderDocIds) {
  if (!orderDocIds?.length) return;
  const batch = writeBatch(db);
  orderDocIds.forEach((id) => {
    batch.update(doc(db, "orders", id), {
      status: "PACKED",
      updatedAt: serverTimestamp(),
    });
  });
  await batch.commit();
}

/**
 * Marks one or more order docs as DELIVERED in a single atomic batch — the
 * Delivery screen's "Mark Delivered" action (see AdminDelivery.jsx). Jumps
 * straight to DELIVERED regardless of whether the order is currently PACKED
 * or OUT_FOR_DELIVERY, since the Delivery screen already only lists orders
 * that are physically on their way — there's no separate admin step for
 * "left the shop" vs "arrived". Writes the same `status` field the Orders
 * page's own per-order "Mark Delivered" action uses, so both stay in sync
 * automatically through the shared orders listener (AdminDataContext) —
 * whichever screen updates it, every screen reading `orders` sees it live.
 */
export async function markOrdersDelivered(db, orderDocIds) {
  if (!orderDocIds?.length) return;
  const batch = writeBatch(db);
  orderDocIds.forEach((id) => {
    batch.update(doc(db, "orders", id), {
      status: "DELIVERED",
      updatedAt: serverTimestamp(),
    });
  });
  await batch.commit();
}

/**
 * Marks one or more order docs as OUT_FOR_DELIVERY in a single atomic
 * batch — the Delivery screen's "Mark Out for Delivery" action, the step
 * between Packed and Delivered (see AdminDelivery.jsx). Delivered still
 * means "handed off to the transport office", not "in the customer's
 * hands" — this step just records that the parcel has physically left
 * for dispatch.
 */
export async function markOrdersOutForDelivery(db, orderDocIds) {
  if (!orderDocIds?.length) return;
  const batch = writeBatch(db);
  orderDocIds.forEach((id) => {
    batch.update(doc(db, "orders", id), {
      status: "OUT_FOR_DELIVERY",
      updatedAt: serverTimestamp(),
    });
  });
  await batch.commit();
}

/**
 * Generic batch status patch — same shape as markOrdersPacked/
 * markOrdersDelivered/markOrdersOutForDelivery but for any patch instead of
 * a single hardcoded status. Used by the dedicated Payment Confirmation /
 * Packing / Delivery screens' "revoke" actions to undo an accidental
 * advance across a whole customer cluster (multiple order docs) at once.
 */
export async function updateOrdersStatus(db, orderDocIds, patch) {
  if (!orderDocIds?.length) return;
  const batch = writeBatch(db);
  orderDocIds.forEach((id) => {
    batch.update(doc(db, "orders", id), { ...patch, updatedAt: serverTimestamp() });
  });
  await batch.commit();
}

/**
 * Permanently deletes an order document — admin-only, irreversible. Used
 * from the "Delete Order" action on the Order Management page. Note: this
 * does not touch a linked invoice (orders/{id}.invoiceId), if one exists —
 * the invoice stays on the Invoices page and can be deleted separately.
 */
export async function deleteOrderDoc(db, orderDocId) {
  await deleteDoc(doc(db, "orders", orderDocId));
}
