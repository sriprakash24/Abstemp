import { useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { AnimatePresence, motion } from 'framer-motion';
import { LazyLoadImage } from 'react-lazy-load-image-component';
import 'react-lazy-load-image-component/src/effects/opacity.css';
import { ChevronDown, Copy, MapPin, MessageCircleMore, Download, Loader2, Pencil, Receipt, PackageSearch, TrendingUp } from 'lucide-react';
import { toast } from 'sonner';
import { getOrderStatusMeta, normalizeOrderStage, isOrderStageComplete } from '../../constants/orderStatusMeta';
import OrderStatusStepper from '../checkout/OrderStatusStepper';
import { db } from '../../firebase/config';
import { getInvoice } from '../../services/invoicesFirestore';
import { generateInvoicePdf } from '../../utils/generateInvoicePdf';
import { generateBillPdf } from '../../utils/generateBillPdf';
import { downloadPackingListPdf } from '../../utils/generatePackingListPdf';
import { useProducts } from '../../contexts/ProductsContext';
import { useCartStore } from '../../store/useCartStore';
import { repriceFromCatalog } from '../../utils/orderPricing';

function formatOrderDate(createdAt) {
  const date = createdAt?.toDate ? createdAt.toDate() : createdAt ? new Date(createdAt) : null;
  if (!date || Number.isNaN(date.getTime())) return 'Just now';
  return date.toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' });
}

export default function OrderCard({ order, delay = 0 }) {
  const [open, setOpen] = useState(false);
  const [downloadingInvoice, setDownloadingInvoice] = useState(false);
  const [downloadingBill, setDownloadingBill] = useState(false);
  const [downloadingPackingList, setDownloadingPackingList] = useState(false);
  const navigate = useNavigate();
  const startEditOrder = useCartStore((s) => s.startEditOrder);
  const { products, productsById } = useProducts();
  // Same live-repricing rule as the admin dashboard: an order still sitting
  // in AWAITING_ADMIN_CONFIRMATION hasn't been paid for yet, so if admin
  // updates a product's price in that window (e.g. a restock), the customer
  // should see today's price here too — not the stale one from checkout.
  // Once admin confirms payment (or pins the original price via
  // priceOverride: "original"), this stops applying and the order renders
  // exactly as stored, same as before.
  const isAwaitingPayment = order.status === 'AWAITING_ADMIN_CONFIRMATION';
  const useOriginalPrice = order.priceOverride === 'original';
  const liveRepricedOrder = useMemo(() => {
    if (!isAwaitingPayment) return order;
    return repriceFromCatalog(order, productsById);
  }, [order, isAwaitingPayment, productsById]);
  const pricedOrder = useOriginalPrice ? order : liveRepricedOrder;
  const hasPriceChange = isAwaitingPayment && liveRepricedOrder.grandTotal !== order.grandTotal;
  const items = pricedOrder.cartItems || [];
  // Per-item price deltas (checkout price vs. today's live price), so each
  // changed line can carry its own "was ₹X" highlight — not just the total.
  const originalUnitPriceById = useMemo(
    () => Object.fromEntries((order.cartItems || []).map((i) => [i.productId, i.unitPrice])),
    [order.cartItems]
  );
  const priceChangeByProductId = useMemo(() => {
    if (!hasPriceChange) return new Map();
    const map = new Map();
    for (const item of items) {
      const wasPrice = originalUnitPriceById[item.productId];
      if (wasPrice != null && wasPrice !== item.unitPrice) {
        map.set(item.productId, { from: wasPrice, to: item.unitPrice });
      }
    }
    return map;
  }, [items, originalUnitPriceById, hasPriceChange]);
  // Older orders were placed before item.nameTa started being snapshotted
  // at checkout (see ordersFirestore.js) — fall back to the live catalog
  // by productId so those orders still show the Tamil name.
  const nameTaById = useMemo(
    () => Object.fromEntries(products.map((p) => [p.id, p.nameTa])),
    [products]
  );
  const statusMeta = getOrderStatusMeta(order.status);
  const stage = normalizeOrderStage(order.orderStage, order.status);
  const isCancelled = order.status === 'CANCELLED';
  // Manual-payment flow: the order sits at AWAITING_ADMIN_CONFIRMATION
  // until the team confirms payment came through. Editing is only safe
  // in that window — once it's CONFIRMED (or moved further) the order's
  // already been acted on, so the button disappears entirely rather than
  // just disabling, to avoid implying it might still work.
  const canEdit = order.status === 'AWAITING_ADMIN_CONFIRMATION';

  const handleDownloadInvoice = async () => {
    if (!order.invoiceId || downloadingInvoice) return;
    setDownloadingInvoice(true);
    try {
      const invoice = await getInvoice(db, order.invoiceId);
      if (!invoice) {
        toast.error('Invoice not found');
        return;
      }
      generateInvoicePdf(invoice);
    } catch (err) {
      console.error('Failed to download invoice', err);
      toast.error("Couldn't download the invoice. Please try again.");
    } finally {
      setDownloadingInvoice(false);
    }
  };

  // Estimate bill is built straight from the order doc (no Firestore invoice
  // needed), so it's available any time before payment is confirmed. Once
  // payment's confirmed the button gets disabled — the real invoice below
  // takes over as the document of record.
  const handleDownloadBill = () => {
    if (downloadingBill) return;
    setDownloadingBill(true);
    try {
      generateBillPdf(pricedOrder);
    } catch (err) {
      console.error('Failed to download estimate bill', err);
      toast.error("Couldn't download the estimate bill. Please try again.");
    } finally {
      setDownloadingBill(false);
    }
  };

  // Same bare item+quantity list admin packs from — for reference only, so
  // the customer can see exactly what's being packed for their order.
  const handleDownloadPackingList = () => {
    if (downloadingPackingList) return;
    setDownloadingPackingList(true);
    try {
      downloadPackingListPdf({
        merged: false,
        mobile: order.customer?.mobile,
        customerName: order.customer?.name,
        orderLabels: [order.orderId || order.id],
        confirmedDateLabel: formatOrderDate(order.paymentConfirmedAt || order.createdAt),
        items: items.map((item) => ({ name: item.name, quantity: item.quantity })),
      });
    } catch (err) {
      console.error('Failed to build packing list', err);
      toast.error("Couldn't generate the packing list. Please try again.");
    } finally {
      setDownloadingPackingList(false);
    }
  };

  const copyOrderId = async () => {
    try {
      await navigator.clipboard.writeText(order.orderId || order.id);
      toast('Order ID copied');
    } catch {
      toast('Could not copy — long press to select');
    }
  };

  const contactSupport = () => {
    const text = encodeURIComponent(`Hi, I'd like an update on my order ${order.orderId || order.id}.`);
    window.open(`https://wa.me/?text=${text}`, '_blank', 'noopener,noreferrer');
  };

  // Seeds the shopping cart with this order's current items and drops the
  // customer on Home — from there editing is just normal browsing, with
  // EditOrderBar (mounted globally) tracking the running total and handling
  // the final "Review & Update" save back onto this same order doc.
  const handleEditOrder = () => {
    const items = (order.cartItems || []).map((item) => ({
      productId: item.productId,
      quantity: item.quantity,
    }));
    startEditOrder(order.id, items);
    navigate('/');
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 14 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4, delay, ease: 'easeOut' }}
      className="surface-3d overflow-hidden rounded-2xl"
    >
      <div className="flex flex-col gap-3 p-4">
        <div className="flex items-center justify-between gap-2">
          <div className="min-w-0">
            <div className="truncate text-[12.5px] font-extrabold text-brown">{order.orderId || order.id}</div>
            <div className="text-[10px] text-muted">{formatOrderDate(order.createdAt)}</div>
          </div>
          <span
            className={`flex shrink-0 items-center gap-1.5 rounded-full border px-2 py-0.5 text-[10px] font-bold ${statusMeta.className}`}
          >
            {statusMeta.emoji} {statusMeta.label}
          </span>
        </div>

        {/* Always visible — amount and item thumbnails, no need to expand
            the dropdown just to see what you're paying. The chevron here
            is the ONLY thing that toggles the items dropdown below. */}
        <button onClick={() => setOpen((v) => !v)} className="flex items-center gap-2 text-left">
          <div className="flex -space-x-3">
            {items.slice(0, 3).map((item, i) => (
              <div
                key={item.productId || i}
                className="orb-3d orb-cream flex h-11 w-11 shrink-0 items-center justify-center overflow-hidden !rounded-lg"
                style={{ zIndex: 3 - i }}
              >
                {item.image ? (
                  <LazyLoadImage src={item.image} alt={item.name} effect="opacity" className="h-full w-full object-contain" />
                ) : (
                  <span className="text-base">🎆</span>
                )}
              </div>
            ))}
            {items.length > 3 && (
              <div className="orb-3d flex h-11 w-11 shrink-0 items-center justify-center !rounded-lg text-[10px] font-bold text-gold">
                +{items.length - 3}
              </div>
            )}
          </div>

          <div className="min-w-0 flex-1 pl-1">
            <div className="text-[11px] font-semibold text-muted">
              {items.length} {items.length === 1 ? 'item' : 'items'}
            </div>
            <div className="text-[14px] font-extrabold text-gradient-gold">
              ₹{(pricedOrder.grandTotal ?? 0).toLocaleString('en-IN')}
            </div>
          </div>

          <motion.span
            animate={{ rotate: open ? 180 : 0 }}
            transition={{ duration: 0.25 }}
            className="orb-3d flex h-8 w-8 shrink-0 items-center justify-center !rounded-full text-orange"
          >
            <ChevronDown size={15} />
          </motion.span>
        </button>

        {/* Always visible — the actions customers actually need in a hurry,
            right on the card face instead of buried behind the dropdown.
            Estimate Bill is available before payment is confirmed and gets
            disabled the moment it is; Edit Order swaps for Download Invoice
            at that same moment, since editing is no longer safe once the
            order's been acted on. */}
        <button
          type="button"
          onClick={handleDownloadBill}
          disabled={!canEdit || downloadingBill}
          className="btn-3d-outline flex items-center justify-center gap-1.5 rounded-xl py-2.5 text-[11px] font-bold text-gold disabled:opacity-50"
        >
          {downloadingBill ? <Loader2 size={13} className="animate-spin" /> : <Receipt size={13} />}
          Download Estimate Bill
        </button>

        {canEdit ? (
          <button
            type="button"
            onClick={handleEditOrder}
            className="btn-3d flex items-center justify-center gap-1.5 rounded-xl py-2.5 text-[11.5px] font-extrabold text-white"
          >
            <Pencil size={13} />
            Edit Order
          </button>
        ) : (
          !isCancelled && (
            <>
              <button
                type="button"
                onClick={handleDownloadPackingList}
                disabled={downloadingPackingList}
                className="btn-3d-outline flex items-center justify-center gap-1.5 rounded-xl py-2.5 text-[11px] font-bold text-gold disabled:opacity-50"
              >
                {downloadingPackingList ? <Loader2 size={13} className="animate-spin" /> : <PackageSearch size={13} />}
                Packing List (Items &amp; Qty)
              </button>
              <button
                type="button"
                onClick={handleDownloadInvoice}
                disabled={!order.invoiceId || downloadingInvoice}
                style={{ borderColor: 'rgba(143, 227, 160, 0.55)' }}
                className="btn-3d-outline flex items-center justify-center gap-1.5 rounded-xl py-2.5 text-[11.5px] font-extrabold text-[#1E8E4A] disabled:opacity-50"
              >
                {downloadingInvoice ? <Loader2 size={13} className="animate-spin" /> : <Download size={13} />}
                Download Invoice
              </button>
            </>
          )
        )}
      </div>

      <AnimatePresence initial={false}>
        {open && (
          <motion.div
            key="content"
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.3, ease: 'easeInOut' }}
            className="overflow-hidden"
          >
            <div className="flex flex-col gap-3 border-t border-dashed border-brown/12 px-4 pb-4 pt-3.5">
              <div className="flex flex-col divide-y divide-white/[0.06]">
                {items.map((item, i) => {
                  const priceChange = priceChangeByProductId.get(item.productId);
                  return (
                  <div
                    key={item.productId || i}
                    className={`flex items-center gap-3 py-2 first:pt-0 last:pb-0 ${
                      priceChange ? '-mx-2 rounded-lg border border-gold/30 bg-gold/[0.06] px-2' : ''
                    }`}
                  >
                    <div className="orb-3d orb-cream flex h-10 w-10 shrink-0 items-center justify-center overflow-hidden !rounded-lg">
                      {item.image ? (
                        <LazyLoadImage src={item.image} alt={item.name} effect="opacity" className="h-full w-full object-contain" />
                      ) : (
                        <span className="text-sm">🎆</span>
                      )}
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="line-clamp-1 text-[11.5px] font-bold text-brown">{item.name}</div>
                      {(item.nameTa || nameTaById[item.productId]) && (
                        <div className="line-clamp-1 text-[10px] font-semibold text-gold">
                          {item.nameTa || nameTaById[item.productId]}
                        </div>
                      )}
                      <div className="mt-0.5 text-[10px] text-muted">
                        Qty {item.quantity} × ₹{item.unitPrice}
                      </div>
                      {priceChange && (
                        <div className="mt-0.5 text-[9px] font-semibold text-gold">Restocked · price refreshed</div>
                      )}
                    </div>
                    <div className="shrink-0 text-[12px] font-extrabold text-gold">₹{item.lineTotal}</div>
                  </div>
                  );
                })}
              </div>

              {hasPriceChange && (
                <div className="flex items-start gap-2 rounded-xl border border-gold/30 bg-gold/[0.06] px-3 py-2.5 text-[10.5px] leading-relaxed text-gold">
                  <TrendingUp size={13} className="mt-0.5 shrink-0" />
                  <span>Some items were restocked, so the highlighted price(s) above have been refreshed.</span>
                </div>
              )}

              {order.address && (
                <div className="flex items-start gap-2 rounded-xl bg-brown/8 px-3 py-2.5 text-[10.5px] leading-relaxed text-muted">
                  <MapPin size={13} className="mt-0.5 shrink-0 text-orange" />
                  <span>
                    {[order.address.houseNumber, order.address.street, order.address.area, order.address.city, order.address.district, order.address.state, order.address.pincode]
                      .filter(Boolean)
                      .join(', ')}
                  </span>
                </div>
              )}

              {!isCancelled && (
                <div className="flex justify-center">
                  <OrderStatusStepper currentStageId={stage} completed={isOrderStageComplete(order.status)} delay={0.05} />
                </div>
              )}

              <div className="flex items-center gap-2 border-t border-dashed border-brown/12 pt-3">
                <button
                  onClick={copyOrderId}
                  className="btn-3d-outline flex flex-1 items-center justify-center gap-1.5 rounded-xl py-2.5 text-[11px] font-bold text-gold"
                >
                  <Copy size={13} />
                  Copy Order ID
                </button>
                <button
                  onClick={contactSupport}
                  className="btn-3d flex flex-1 items-center justify-center gap-1.5 rounded-xl py-2.5 text-[11px] font-extrabold text-black"
                >
                  <MessageCircleMore size={13} />
                  WhatsApp Us
                </button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}
