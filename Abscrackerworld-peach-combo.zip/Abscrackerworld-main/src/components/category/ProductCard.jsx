import { motion } from 'framer-motion';
import { LazyLoadImage } from 'react-lazy-load-image-component';
import 'react-lazy-load-image-component/src/effects/opacity.css';
import { showAddedToast, showRemovedToast } from '../../utils/cartToast';
import { useCartStore } from '../../store/useCartStore';
import { useCustomerGateStore } from '../../store/useCustomerGateStore';
import { getOrderQtyCap } from '../../utils/productLimits';
import ProductBadges from './ProductBadges';
import WishlistButton from './WishlistButton';
import PriceSection from './PriceSection';
import AddToCartButton from './AddToCartButton';

const cardVariants = {
  hidden: { opacity: 0, y: 22 },
  show: { opacity: 1, y: 0, transition: { duration: 0.45, ease: 'easeOut' } },
};

const STOCK_META = {
  in: { text: 'In Stock', className: 'text-[#1E8E4A]' },
  out: { text: 'Sold Out', className: 'text-[#e35226]' },
};

export default function ProductCard({ product, theme }) {
  const inCart = useCartStore((s) => s.cart[product.id] || 0);
  const wished = useCartStore((s) => !!s.wishlist[product.id]);
  const addToCart = useCartStore((s) => s.addToCart);
  const incrementQty = useCartStore((s) => s.incrementQty);
  const decrementQty = useCartStore((s) => s.decrementQty);
  const removeFromCart = useCartStore((s) => s.removeFromCart);
  const setQuantity = useCartStore((s) => s.setQuantity);
  const toggleWishlist = useCartStore((s) => s.toggleWishlist);
  const requestDetails = useCustomerGateStore((s) => s.requestDetails);

  const soldOut = product.stock === 'out';
  const accent = theme?.solid || 'var(--color-orange)';
  const { cap: maxQty, limitedByOrder } = getOrderQtyCap(product);

  return (
    <motion.div
      id={`product-card-${product.id}`}
      variants={cardVariants}
      initial="hidden"
      whileInView="show"
      viewport={{ once: true, amount: 0.25 }}
      whileHover={{ y: -4 }}
      whileTap={{ scale: 0.98 }}
      className="surface-3d group relative flex flex-col overflow-hidden rounded-2xl p-2.5 transition-shadow duration-300"
      style={{ borderColor: `${accent}70` }}
      onMouseEnter={(e) => {
        e.currentTarget.style.boxShadow = `0 0 22px ${accent}70`;
      }}
      onMouseLeave={(e) => {
        e.currentTarget.style.boxShadow = '';
      }}
    >
      {/* Bold category-color band — thick enough to read at a glance, plus
          a soft wash of the same color bleeding down from the top corner,
          so cards from different categories are distinguishable even when
          scrolled past quickly, not just on close inspection. */}
      <span
        className="pointer-events-none absolute inset-x-0 top-0 z-10 h-[6px]"
        style={{
          background: theme ? `linear-gradient(90deg, ${theme.from}, ${theme.to})` : accent,
          boxShadow: `0 0 14px 1px ${accent}90`,
        }}
      />
      <span
        className="pointer-events-none absolute inset-x-0 top-0 z-0 h-20 opacity-25"
        style={{ background: `radial-gradient(circle at 18% 0%, ${theme?.from || accent}, transparent 70%)` }}
      />

      <ProductBadges product={product} />
      <WishlistButton active={wished} onToggle={() => toggleWishlist(product.id)} />

      {/* Colored frame around the photo panel — the single biggest area on
          the card, so giving it a category-tinted ring (instead of a
          neutral border) is the fastest way to tell two cards apart. */}
      <div
        className="relative z-[1] rounded-xl p-[2px]"
        style={{ background: theme ? `linear-gradient(135deg, ${theme.from}, ${theme.to})` : accent }}
      >
        <div className="orb-3d orb-cream relative flex h-[82px] items-center justify-center overflow-hidden !rounded-[10px]">
          {product.img ? (
            <LazyLoadImage
              src={product.img}
              alt={product.name}
              effect="opacity"
              className="h-full w-full object-contain transition-transform duration-300 group-hover:scale-110"
            />
          ) : (
            <span className="art-float text-3xl">🎆</span>
          )}
          {soldOut && (
            <div className="absolute inset-0 flex items-center justify-center bg-black/55">
              <span className="rounded-full border border-white/20 bg-black/50 px-2 py-0.5 text-[9px] font-bold tracking-wide text-white">
                SOLD OUT
              </span>
            </div>
          )}
        </div>
      </div>

      <div className="mt-2 line-clamp-2 min-h-[30px] text-[12px] font-bold leading-snug text-brown">
        {product.name}
      </div>
      {product.nameTa && (
        <div className="-mt-0.5 line-clamp-1 text-[10.5px] font-semibold leading-snug text-gold">
          {product.nameTa}
        </div>
      )}
      <div className="flex items-center justify-between">
        <span className="text-[10px] text-muted">{product.unit}</span>
        {product.stock === 'low' ? (
          <span className="rounded-full border border-gold/40 bg-gold/10 px-1.5 py-0.5 text-[9px] font-bold text-gold">
            Limited Stock · {product.stockQty} left
          </span>
        ) : (
          <span className={`text-[9.5px] font-bold ${STOCK_META[product.stock]?.className || STOCK_META.in.className}`}>
            {STOCK_META[product.stock]?.text || STOCK_META.in.text}
          </span>
        )}
      </div>

      <PriceSection mrp={product.mrp} sale={product.sale} discountPercentage={product.discountPercentage} />

      <AddToCartButton
        inCart={inCart}
        disabled={soldOut}
        maxQty={maxQty}
        limitedByOrder={limitedByOrder}
        productName={product.name}
        onAdd={() => {
          requestDetails(() => {
            addToCart(product.id);
            showAddedToast(product.name);
          });
        }}
        onIncrement={() => incrementQty(product.id)}
        onDecrement={() => {
          if (inCart <= 1) {
            removeFromCart(product.id);
            showRemovedToast(product.name);
          } else {
            decrementQty(product.id);
          }
        }}
        onSetQuantity={(qty) => setQuantity(product.id, qty)}
      />
    </motion.div>
  );
}
