import { LogOut, ShieldCheck } from 'lucide-react';
import absLogo from '../../assets/abs-logo.png';

export default function AdminOrdersHeader({ email, orderCount, onLogout }) {
  return (
    <div
      className="glass relative sticky top-0 z-30 flex items-center justify-between gap-3 overflow-hidden px-4 py-3.5 sm:px-6"
      style={{
        borderBottom: '1px solid rgba(255,154,0,.22)',
        boxShadow: '0 10px 26px -14px rgba(113,50,31,0.20), 0 0 20px rgba(255,122,0,.1)',
      }}
    >
      <div
        className="pointer-events-none absolute inset-x-0 top-0 -z-10 h-full"
        style={{ background: 'radial-gradient(ellipse at 50% 0%, rgba(255,122,0,0.14) 0%, transparent 70%)' }}
      />

      <div className="flex min-w-0 items-center gap-2.5">
        <img
          src={absLogo}
          alt="ABS Crackers World"
          className="hidden h-8 w-8 shrink-0 object-contain sm:block"
          style={{ filter: 'drop-shadow(0 0 6px rgba(255,150,0,.5))' }}
        />
        <span className="orb-3d flex h-9 w-9 shrink-0 items-center justify-center !rounded-full text-orange">
          <ShieldCheck size={17} />
        </span>
        <div className="min-w-0">
          <div className="flex items-center gap-2">
            <h1 className="truncate text-[14px] font-extrabold tracking-wide text-gradient-gold">Order Management</h1>
            <span className="flex shrink-0 items-center gap-1 rounded-full border border-[#1E8E4A]/35 bg-[#1E8E4A]/10 px-1.5 py-0.5 text-[9px] font-bold text-[#1E8E4A]">
              <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-[#1E8E4A]" />
              LIVE
            </span>
          </div>
          <p className="truncate text-[11px] font-semibold text-muted">
            {email} · {orderCount} {orderCount === 1 ? 'order' : 'orders'} total
          </p>
        </div>
      </div>

      <button
        onClick={onLogout}
        className="flex shrink-0 items-center gap-1.5 rounded-xl border border-brown/12 bg-white px-3.5 py-2 text-[11.5px] font-bold text-brown transition-colors hover:border-orange/50 hover:text-orange"
      >
        <LogOut size={13} />
        <span className="hidden sm:inline">Sign Out</span>
      </button>
    </div>
  );
}
